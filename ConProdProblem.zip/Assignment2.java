// N = 100, K = 10, T = 2

public class Assignment2 
{
	public static void main(String arg[]) throws Exception
	{
		if (arg.length < 3)
			System.out.println("Invalid no of arguments");
		else
		{
			final ProducerConsumer pc = new ProducerConsumer(Integer.parseInt(arg[0]),Integer.parseInt(arg[1]),Integer.parseInt(arg[2]));
			Thread t1 = new Thread(new Runnable ()
			{
				public void run()
				{
					try 
					{
						pc.producer();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			});
			
			Thread t2 = new Thread(new Runnable ()
			{
				public void run()
				{
					try 
					{
						pc.consumer();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			});
			
			t1.start();
			t2.start();
			
			t1.join();
			t2.join();
		}
		
	}
}
