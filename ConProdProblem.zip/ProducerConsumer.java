import java.util.ArrayList;
import java.util.Random;

public class ProducerConsumer 
{
	ArrayList <Integer> buffer;
	int time;
	int k;
	int size;
	Random random;
	
	ProducerConsumer()
	{
		
	}
	
	ProducerConsumer(int n, int k, int t)
	{
		size = n;
		this.k = k;
		time = t;
		buffer = new ArrayList <Integer> ();
		for (int i = 0; i < size; i++)
			buffer.add(0);
		System.out.println("Size: " + size);
		System.out.println("K: " + k);
		System.out.println("Time: " + time);
		random = new Random();
	}
	
	public void producer() throws Exception
	{
		int next = 0;
		int k1;
		int t1;
		boolean isTrue = true;
		while (isTrue)
		{
			k1 = random.nextInt(k);
			for (int i = 0; i < k1; i++)
			{
				if (buffer.get((next+i)%size) == 0)
					buffer.set((next+i)%size, buffer.get((next+i)%size)+1);
				else
					isTrue = false;
			}
			next = next + k1;
			t1 = random.nextInt(time);
			Thread.sleep(t1*1000);
		}
		System.out.println("Race Conditions are met");
	}
	
	public void consumer() throws Exception
	{
		int next = 0;
		int k2;
		int t2;
		while (true)
		{
			k2 = random.nextInt(k);
			for (int i = 0; i < k2; i++)
				buffer.set((next+i)%size, 0);
			next = next + k2;
			t2 = random.nextInt(time);
			Thread.sleep(t2*1000);
		}
	}
}
